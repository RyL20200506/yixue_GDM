Navigation_main.py  # 主程序：包括【训练】，【测试】，【画图】

# 按对应原始格式替换数据集即可训练新的模型
data.txt  # 训练集数据
data_ver.txt  # 测试集数据
